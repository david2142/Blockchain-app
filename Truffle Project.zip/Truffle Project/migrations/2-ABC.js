var ABC = artifacts. require(" ./ABC.sol");
mpdule. exports = function (deployer) {
deployer. deploy(ABC) ;
};