var SimpleStorage = artifacts. require(" ./Simp1eStorage.sol");
mpdule.exports = function (deployer) {
deployer.deploy (SimpleStorage);
};